<?php
/*-----------------------------------------------------------------------------------*/
/*  EXTHEM.ES
/*  PREMIUM WORDRESS THEMES
/*
/*  STOP DON'T TRY EDIT
/*  IF YOU DON'T KNOW PHP
/*  AS ERRORS IN YOUR THEMES ARE NOT THE RESPONSIBILITY OF THE DEVELOPERS
/*
/*
/*  @EXTHEM.ES
/*  Follow Social Media Exthem.es
/*  Youtube : https://www.youtube.com/channel/UCpcZNXk6ySLtwRSBN6fVyLA
/*  Facebook : https://www.facebook.com/groups/exthem.es
/*  Twitter : https://twitter.com/ExThemes
/*  Instagram : https://www.instagram.com/exthemescom/
/*	More Premium Themes Visit Now On https://exthem.es/
/*
/*-----------------------------------------------------------------------------------*/ 
require EX_THEMES_DIR.'/libs/elements/widget-slider.php';
require EX_THEMES_DIR.'/libs/elements/widget-slider-by-id.php';
require EX_THEMES_DIR.'/libs/elements/widget-home.php';
require EX_THEMES_DIR.'/libs/elements/widget-news.php';
require EX_THEMES_DIR.'/libs/elements/widget-sidebar.php';
require EX_THEMES_DIR.'/libs/elements/widget-sidebar-rate.php';
require EX_THEMES_DIR.'/libs/elements/widget-sidebar-cat.php';
/*-----------------------------------------------------------------------------------*/
/*  Other widget
/*-----------------------------------------------------------------------------------*/  