<?php
$ssl	= array(
				"ssl"	=>array(
					"verify_peer"		=>false,
					"verify_peer_name"	=>false,
				),
				"http"	=> array(
					"header"			=> "User-Agent: Opera/9.80 (J2ME/MIDP; Opera Mini/4.2 19.42.55/19.892; U; en"
				),
				"https"	=> array(
					"header"			=> "User-Agent: Opera/9.80 (J2ME/MIDP; Opera Mini/4.2 19.42.55/19.892; U; en"
				)
		); 