<?php
/*-----------------------------------------------------------------------------------*/
/*  EXTHEM.ES
/*  PREMIUM WORDRESS THEMES
/*
/*  STOP DON'T TRY EDIT
/*  IF YOU DON'T KNOW PHP
/*  AS ERRORS IN YOUR THEMES ARE NOT THE RESPONSIBILITY OF THE DEVELOPERS
/*
/*  As Errors In Your Themes
/*  Are Not The Responsibility
/*  Of The DEVELOPERS
/*  @EXTHEM.ES
/*-----------------------------------------------------------------------------------*/  
// Silence is golden.
$mdr_xx_0  = BS64D;
// ~~~~~~~~~~~~~~~~~~~~~ @EXTHEMES DEVS ~~~~~~~~~~~~~~~~~~~~~~~~ \\ 
eval($mdr_xx_0("\x43\x69\x42\154\x63\156\112\166\x63\154\71\171\132\130\102\x76\x63\x6e\x52\160\142\155\143\x6f\125\x30\106\x4d\121\125\147\160\x4f\x79\101\75"));
