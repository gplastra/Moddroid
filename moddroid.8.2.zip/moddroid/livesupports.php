<style>@import url(https://fonts.googleapis.com/css?family=Open+Sans);* {box-sizing: border-box;}.wrapper {}header {padding: 0 15px;}.columns {display: flex;flex-flow: row wrap;justify-content: center;margin: 5px 0;}.column {flex: 1;border: 1px solid gray;margin: 2px;padding: 10px;}.column:first-child {margin-left: 0;}.column:last-child {margin-right: 0;}footer {padding: 0 15px;}@media screen and (max-width: 980px) {.columns .column {margin-bottom: 5px;flex-basis: 40%;}.columns .column:nth-last-child(2) {margin-right: 0;}.columns .column:last-child {flex-basis: 100%;margin: 0;}}@media screen and (max-width: 680px) {.columns .column {flex-basis: 100%;margin: 0 0 5px 0;}}body {font-size:80%;color:#222;background:#fff;} 
</style>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v17.0" nonce="gT4bnKrF"></script>
<script src="https://apis.google.com/js/platform.js"></script>
<script type="text/javascript">(function() {var script=document.createElement("script");script.type="text/javascript";script.async =true;script.src="//telegram.im/widget-button/index.php?id=@exthemes_helps";document.getElementsByTagName("head")[0].appendChild(script);})();</script>
<div class="wrap"> 
<div class="wrapper">
	<header>
		<h1> </h1>
		<h1 style="text-align: center;text-transform: uppercase;margin-top: 5rem;">Follow on social media</h1>
	</header>
<center>
<div id="fb-root"></div>
<div style="display: block;margin-left: auto;margin-right: auto;width: 50%;"  class="fb-like" data-href="https://exthem.es/" data-layout="standard" data-action="like" data-show-faces="true" data-share="true"></div>
		<div class="g-ytsubscribe" data-channelid="UCpcZNXk6ySLtwRSBN6fVyLA" data-layout="full" data-count="default"></div>
		<div class="g-ytsubscribe" data-channelid="UCOrw7drqals10l7HVMXovjQ" data-layout="full" data-count="default"></div>
		<div class="g-ytsubscribe" data-channelid="UCI8iG6Qflc9MB3hQwWKFkDA" data-layout="full" data-count="default"></div>
		<br><br>
          <a href="https://telegram.dog/exthemes_helps" target="_blank" class="telegramim_button telegramim_shadow telegramim_pulse" style="font-size:15px;width:200px;background:#2DA5D9;box-shadow:1px 1px 5px #2DA5D9;color:#FFFFFF;border-radius:50px;" title="Join Now"><i class="ftelegramim ftelegramim-telegram-logo"></i> Join on Telegram <small><span class="telegramim_count" data-for="@exthemes_helps"></span> Participants</small></a>
</center>
</div>
</div>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/641bddfc4247f20fefe77d1a/1gs6dm9l1';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<noscript>
<script>
  var url = 'https://exthem.es/telegram.js?43370';
    var s = document.createElement('script');
    s.type = 'text/javascript';
    s.async = true;
    s.src = url;
    var options = {
  "enabled":true,
  "chatButtonSetting":{
      "backgroundColor": "rgb(0, 136, 204)",
      "backgroundColor2": "rgb(0, 136, 204)",
      "ctaText": "",
      "borderRadius": "25",
      "marginLeft": "",
      "marginBottom": "70",
      "marginRight": "20",
      "position": "right"
  },
  "brandSetting":{
      "brandName": "Agent",
	  "brandUrlX": "https://t.me/exthemes",
      "brandSubTitle": "Your a members??... Need Supports??",
      "brandImg":"https://files.elfsight.com/storage/8b3c7ff8-4e48-4113-bff4-06920fe45929/d9b93b48-7941-41ac-92e1-01a0fbf0deea.gif",
      "welcomeText": "Hi, there!👋\nHow can I help you?\n\n*Sorry Only User get Supports\n*Saturday and Sunday we are off for supports",
      "messageText": "Hello, *exthemes* im *YourUsernameonExthemes* I Need Supports.%0A%0A{{page_link}}",
      "backgroundColor": "rgb(0, 136, 204)",
      "backgroundColor2": "rgb(0, 136, 204)",
      "ctaText": "Start Chat",
      "borderRadius": "25",
      "autoShow": false,
      "phoneNumber": "6281144440909"
  }
};
    s.onload = function() {
        CreateWhatsappChatWidget(options);
    };
    var x = document.getElementsByTagName('script')[0];
    x.parentNode.insertBefore(s, x);  
	//Animation. 
</script>
</noscript>