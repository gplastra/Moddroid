			<style>
.swiper{width:100%;padding-top:15px;padding-bottom:15px}.swiper-slide{max-width:100%}.swiper-pagination{bottom:0!important}@media only screen and (min-width:601px){.swiper{height:235px}.swiper-slide{margin-right:15px;max-width:calc((100% - 15px) / 2)}}@media only screen and (min-width:993px){.swiper{height:209px}.swiper-slide{margin-right:15px;max-width:calc((100% - 30px) / 3)}}.animate__fadeIn{animation-name:fadeIn}@keyframes fadeIn{from{opacity:0}to{opacity:1}}
</style>
<link
      rel="stylesheet"
      href="https://unpkg.com/swiper/swiper-bundle.min.css"
    />
	<div class="container">
<div class="swiper mySwiper">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
		 
		<img decoding="async" loading="lazy" src="https://play-lh.googleusercontent.com/20WRzUOzjXVwgKFvl9AcvwClB537qZEfBUe186dEfFgCbWEuPu9_4-FElfHptKoE_g=w720-h310" alt="Among Us APK v2021.11.9.2 (MOD Unlocked All)"  >
		 
		</div>
        <div class="swiper-slide">Slide 2</div>
        <div class="swiper-slide">Slide 3</div> 
      </div>
      <div class="swiper-pagination"></div>
    </div>
		<div class="swiper-container gallery-thumbs">
			<div class="swiper-wrapper">
	<div class="swiper-slide">		 
		<img decoding="async" loading="lazy" src="https://play-lh.googleusercontent.com/20WRzUOzjXVwgKFvl9AcvwClB537qZEfBUe186dEfFgCbWEuPu9_4-FElfHptKoE_g=w720-h310" alt="Among Us APK v2021.11.9.2 (MOD Unlocked All)"  >
		 
		</div>
   
        <div class="swiper-slide">Slide 2</div>
        <div class="swiper-slide">Slide 3</div> 
			</div>
	</div>
</div>

	<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/7.2.0/swiper-bundle.min.js"></script>
		<script>
	      var swiper = new Swiper(".swiper", {
					slidesPerView: 1,
					spaceBetween: 15,
					breakpoints: {
						320: {
							slidesPerView: 1,
							spaceBetween: 15,
						},
						601: {
							slidesPerView: 2,
							spaceBetween: 15,
						},
						993: {
							slidesPerView: 3,
							spaceBetween: 15
						}
					},
					loop: true,
					autoplay: true,
					pagination: {
						el: '.swiper-pagination',
						dynamicBullets: true,
					},
				});
	      var swiper = new Swiper(".gallery-thumbs", {
					slidesPerView: 1,
					spaceBetween: 15,
					breakpoints: {
						320: {
							slidesPerView: 1,
							spaceBetween: 15,
						},
						601: {
							slidesPerView: 2,
							spaceBetween: 15,
						},
						993: {
							slidesPerView: 3,
							spaceBetween: 15
						}
					},
					loop: true,
					autoplay: true,
					pagination: {
						el: '.swiper-pagination',
						dynamicBullets: true,
					},
				});
		</script>