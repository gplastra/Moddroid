 
<style id='custom-new-style-<?php echo strtolower(THEMES_NAMES); ?>-v<?php echo VERSION; ?>'>
</style>