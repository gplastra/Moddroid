
<style id='rtl-style-css-<?php echo THEMES_NAMES; ?>-v<?php echo VERSION; ?>'></style>
