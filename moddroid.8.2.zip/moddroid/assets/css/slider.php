
<style id='slider-style-<?php echo strtolower(THEMES_NAMES); ?>-v<?php echo EXTHEMES_VERSION; ?>'></style>