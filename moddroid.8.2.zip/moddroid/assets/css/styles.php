<style id='style-css-<?php echo strtolower(THEMES_NAMES); ?>-v<?php echo VERSION; ?>'>
</style>
